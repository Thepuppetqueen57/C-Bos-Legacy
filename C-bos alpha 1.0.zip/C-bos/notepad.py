import os
print("for now you can only write 1 line :(")
line = ">"
edit = input(line)
print("Save File!")
saver = input("file name:")
hey = open(saver,"w")
hey.write(edit)
exit()
